import interface

if __name__ == "__main__":
    app = interface.Interface()
    app.mainloop()