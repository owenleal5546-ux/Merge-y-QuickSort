import gui

if __name__ == "__main__":
    app = gui.Interface()
    app.mainloop()